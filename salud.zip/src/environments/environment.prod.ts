export const environment = {
  production: true,
  apiBackEndURL: 'https://webapp.mdsmp.gob.pe/sanidadbackend/public/v1/',
  apiUtilitarios: 'https://webapp.mdsmp.gob.pe/pide/public/',
  apiMaster: 'https://webapp.mdsmp.gob.pe/masterbackend/public/v1/',
};
