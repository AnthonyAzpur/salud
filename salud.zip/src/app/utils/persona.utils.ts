import { Injectable } from '@angular/core';
import { post } from 'jquery';

@Injectable({
    providedIn: 'root'
})
export class PersonaUtils {

    constructor() {
    }


}